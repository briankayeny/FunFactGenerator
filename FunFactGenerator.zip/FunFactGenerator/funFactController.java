package com.example.funfact.controller;

import com.example.funfact.model.FunFact;
import com.example.funfact.service.FunFactService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class FunFactController {

    private final FunFactService funFactService;

    @Autowired
    public FunFactController(FunFactService funFactService) {
        this.funFactService = funFactService;
    }

    @GetMapping("/api/funfact")
    public FunFact getFunFact() {
        return funFactService.getRandomFact();
    }
}
