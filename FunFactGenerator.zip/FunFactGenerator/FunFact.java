package com.example.funfact.model;

public class FunFact {
    private String text;

    public FunFact() {}

    public FunFact(String text) {
        this.text = text;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }
}
