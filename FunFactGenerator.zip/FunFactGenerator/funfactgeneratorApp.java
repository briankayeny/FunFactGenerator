package com.example.funfact;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FunFactGeneratorApp {
    public static void main(String[] args) {
        SpringApplication.run(FunFactGeneratorApp.class, args);
    }
}
